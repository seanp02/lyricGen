import openai
import os
from google.cloud import texttospeech
from pydub import AudioSegment

# 환경 변수 로드 (OpenAI API 키와 Google Cloud TTS 서비스 계정 키 파일 경로)
from dotenv import load_dotenv
load_dotenv()

openai.api_key = os.getenv('OPENAI_API_KEY')
os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = os.getenv('GOOGLE_APPLICATION_CREDENTIALS')

def generate_lyrics(title, diary, style):
    # 감정 분석
    emotion_prompt = f"다음 일기의 감정을 분석해 주세요: {diary}"
    emotion_response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "당신은 감정 분석가입니다."},
            {"role": "user", "content": emotion_prompt}
        ],
        max_tokens=50,
        n=1,
        stop=None,
        temperature=0.7,
    )
    
    emotion = emotion_response.choices[0].message['content']
    
    # 가사 생성
    prompt = f"다음 일기 내용을 바탕으로 {style} 스타일의 한국어 노래 가사를 작성해주세요. " \
             f"노래 가사는 전문적이고 맞춤법이 정확해야 하며, 각 파트 (예: [Verse], [Chorus], [Bridge])를 명확히 표시해주세요. " \
             f"감정: {emotion}\n\n일기 제목: {title}\n\n일기 내용:\n{diary}\n\n노래 가사:"
    
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "당신은 창의적인 작사가입니다."},
            {"role": "user", "content": prompt}
        ],
        max_tokens=400,
        n=1,
        stop=None,
        temperature=0.7,
    )
    
    return response.choices[0].message['content']

def synthesize_speech(text, output_file):
    client = texttospeech.TextToSpeechClient()
    synthesis_input = texttospeech.SynthesisInput(text=text)
    voice = texttospeech.VoiceSelectionParams(
        language_code="ko-KR", ssml_gender=texttospeech.SsmlVoiceGender.NEUTRAL)
    audio_config = texttospeech.AudioConfig(
        audio_encoding=texttospeech.AudioEncoding.MP3)
    response = client.synthesize_speech(
        input=synthesis_input, voice=voice, audio_config=audio_config)

    with open(output_file, "wb") as out:
        out.write(response.audio_content)

def combine_audio(vocals_file, backing_track_file, output_file):
    backing_track = AudioSegment.from_file(backing_track_file)
    vocals = AudioSegment.from_file(vocals_file)
    combined = backing_track.overlay(vocals)
    combined.export(output_file, format="mp3")

def main():
    title = "예시 제목"
    diary = "오늘은 날씨가 정말 좋았다. 친구들과 함께 공원에서 피크닉을 즐겼다. 모두가 웃고 즐거워하는 모습을 보니 나도 기분이 좋아졌다."
    style = "발라드"

    # 가사 생성
    lyrics = generate_lyrics(title, diary, style)
    print("생성된 가사:")
    print(lyrics)

    # 음성 합성
    synthesize_speech(lyrics, "output.mp3")

    # 반주와 결합
    combine_audio("output.mp3", "backing_track.mp3", "final_song.mp3")
    print("최종 노래가 'final_song.mp3'에 저장되었습니다.")

if __name__ == "__main__":
    main()
